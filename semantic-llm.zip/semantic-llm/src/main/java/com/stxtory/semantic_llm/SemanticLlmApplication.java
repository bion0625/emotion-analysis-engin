package com.stxtory.semantic_llm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemanticLlmApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemanticLlmApplication.class, args);
	}

}
